import React from 'react';
import s from "./Dialogs.module.css";
import Message from "./Message/Message";
import DialogItem from "./DialogItem/DialogsItem";


const Dialogs = (props) => {

    let dialogsData = [
        {id: 1, name: 'Dima'},
        {id: 2, name: 'Natasha'},
        {id: 3, name: 'Sonya'},
        {id: 4, name: 'Vitya'},
        {id: 5, name: 'Pasha'}
    ]

    let messageData =[
        {id: 1, message: 'Privet'},
        {id: 2, message: 'Poka'},
        {id: 3, message: 'Sosiska'},
    ]

    let dialogsElemets = dialogsData
        .map( d => <DialogItem name={d.name} id={d.id}/>);

    let messageElements = messageData
        .map( m => <Message message={m.message} id={m.id}/>);

    return (
        <div className={s.dialogs}>
            <div className={s.dialogItems}>
                { dialogsElemets }
            </div>
            <div className={s.messages}>
                { messageElements }
            </div>
        </div>
    )
}

export default Dialogs;