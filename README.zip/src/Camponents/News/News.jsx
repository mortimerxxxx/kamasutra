import React from 'react';
import s from "./News.module.css";

const News = (props) => {
    return (
        <div className={s.dialogs}>
            Здесь отображаются самые свежие новости
        </div>
    )
}

export default News;