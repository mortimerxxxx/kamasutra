import React from 'react';
import s from './MyPosts.module.css'
import Post from "./Post/Post";
const MyPosts = (props) => {

    let postData = [
        {id: 1, message: 'Привет! Это моя новая страничка!', likeCount: 12},
        {id: 2, message: 'Не мог завести страничку раньше(((', likeCount: 3},
        {id: 2, message: '#СуперБос', likeCount: 100}
    ]

    let postElements = postData
        .map( p => <Post message={p.message} likeCount={p.likeCount}/>);

    return (
        <div className={s.content}>
            <div className={s.inputBtn}>
                <textarea name="" id="" cols="30" rows="10"></textarea>
                <button>Добавить новый пост</button>
            </div>
            <div className={s.posts}>
                { postElements }
            </div>
        </div>
    )
}

export default MyPosts