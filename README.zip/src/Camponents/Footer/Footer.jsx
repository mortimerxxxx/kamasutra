import React from 'react';
import s from './Footer.module.css'

const Footer = () => {
    return (
        <div className={s.footer}>
            <div>
                СуперReact 2020
            </div>
        </div>
    )
}

export default Footer